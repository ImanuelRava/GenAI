"""
Integration test for RAL Database + RAG + Similarity system.
Tests database loading, search, RAG retrieval, prompt enhancement,
and UMAP/PCA-based ligand similarity.
"""

import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'backend'))

from modules.ral_database import RALDatabase, get_ral_database
from modules.ral_rag import RALRAG, get_ral_rag


def test_database_load():
    print("=" * 60)
    print("TEST 1: Database Loading")
    print("=" * 60)

    db = RALDatabase()
    ok = db.load()

    assert ok, "Database failed to load!"
    print(f"  [PASS] Loaded: {len(db.ligands)} ligands, {len(db.reactions)} reactions")

    stats = db.get_statistics()
    print(f"  Stats: {stats}")
    assert stats['ligands'] == 238, f"Expected 238 ligands, got {stats['ligands']}"
    assert stats['reactions_total'] == 231, f"Expected 231 reactions, got {stats['reactions_total']}"
    assert stats['reactions_curated'] == 49, f"Expected 49 curated, got {stats['reactions_curated']}"
    print(f"  [PASS] All counts correct")


def test_ligand_search():
    print("\n" + "=" * 60)
    print("TEST 2: Ligand Search")
    print("=" * 60)

    db = get_ral_database()

    # Search by class name
    results = db.search_ligands("Bipy", limit=3)
    print(f"  Search 'Bipy': {len(results)} results")
    assert len(results) > 0, "No results for 'Bipy'"
    for r in results[:2]:
        print(f"    - {r['name']} ({r['class']}): HOMO={r['HOMO_eV']}, Gap={r['Gap_eV']}")
    print(f"  [PASS] Bipy search works")

    # Search by specific ligand name
    results = db.search_ligands("PyrOx", limit=3)
    print(f"  Search 'PyrOx': {len(results)} results")
    assert len(results) > 0
    assert results[0]['class'] == 'PyrOx'
    print(f"  [PASS] PyrOx search works, class={results[0]['class']}")

    # Search with class filter
    results = db.search_ligands("bromo", ligand_class="Phen", limit=5)
    print(f"  Search 'bromo' in Phen: {len(results)} results")
    for r in results[:3]:
        assert r['class'] == 'Phen'
    print(f"  [PASS] Class filter works")


def test_ligand_classes():
    print("\n" + "=" * 60)
    print("TEST 3: Ligand Classes Summary")
    print("=" * 60)

    db = get_ral_database()
    classes = db.get_ligand_classes()

    print(f"  {len(classes)} classes:")
    for cls, info in classes.items():
        print(f"    {cls}: {info['count']} ligands, "
              f"HOMO [{info['HOMO_range'][0]:.2f}, {info['HOMO_range'][1]:.2f}], "
              f"Gap [{info['Gap_range'][0]:.2f}, {info['Gap_range'][1]:.2f}]")
    assert len(classes) == 7, f"Expected 7 classes, got {len(classes)}"
    print(f"  [PASS] All 7 classes present")


def test_class_comparison():
    print("\n" + "=" * 60)
    print("TEST 4: Class Comparison")
    print("=" * 60)

    db = get_ral_database()
    comp = db.compare_ligand_classes("Bipy", "Phen")

    assert comp is not None, "Comparison returned None"
    print(f"  Bipy vs Phen:")
    for attr in ['homo', 'lumo', 'gap', 'omega']:
        a_val = comp[attr]['Bipy']
        b_val = comp[attr]['Phen']
        diff = comp[attr]['diff']
        print(f"    {attr}: Bipy={a_val:.3f}, Phen={b_val:.3f}, diff={diff:+.3f}")
    print(f"  [PASS] Comparison works")


def test_reaction_search():
    print("\n" + "=" * 60)
    print("TEST 5: Reaction-Ligand Literature Search")
    print("=" * 60)

    db = get_ral_database()

    # Search by coupling type
    results = db.search_reactions("bipyridine", limit=3)
    print(f"  Search 'bipyridine': {len(results)} curated results")
    for r in results[:2]:
        print(f"    - [{r['mapped_class']}] {r['title'][:80]}...")
        print(f"      Ligand: {r['optimum_ligand'][:60]}")
    assert len(results) > 0, "No reaction results for 'bipyridine'"
    print(f"  [PASS] Reaction search works")

    # Search by DOI
    entry = db.get_reaction_by_doi("10.1055/s-0040-1719881")
    assert entry is not None, "DOI lookup failed"
    print(f"  DOI lookup: {entry['optimum_ligand']}")
    assert "Imidazole" in entry['optimum_ligand']
    print(f"  [PASS] DOI lookup works")


def test_combined_search():
    print("\n" + "=" * 60)
    print("TEST 6: Combined Cross-Database Search")
    print("=" * 60)

    db = get_ral_database()

    combined = db.search_combined("bipyridine reductive coupling", max_ligands=3, max_reactions=3)
    print(f"  Combined search: {combined['ligand_count']} ligands, {combined['reaction_count']} reactions")
    print(f"  Detected class: {combined['detected_class']}")
    for l in combined['ligands'][:2]:
        print(f"    Ligand: {l['name']} (Gap={l['Gap_eV']:.3f})")
    for r in combined['reactions'][:2]:
        print(f"    Reaction: {r['title'][:70]}...")
    print(f"  [PASS] Combined search works")


def test_rag_retrieval():
    print("\n" + "=" * 60)
    print("TEST 7: RAG Context Retrieval")
    print("=" * 60)

    rag = get_ral_rag()

    # Test query about ligand properties
    print("\n  --- Query: 'What is the HOMO-LUMO gap of PyrOx ligands?' ---")
    context = rag.retrieve_context("What is the HOMO-LUMO gap of PyrOx ligands?")
    scores = rag.analyze_query("What is the HOMO-LUMO gap of PyrOx ligands?")
    print(f"  Intent scores: {scores}")
    print(f"  Retrieved: {len(context.ligands)} ligands, {len(context.reactions)} reactions")
    print(f"  Detected class: {context.detected_class}")
    assert context.detected_class == 'PyrOx', f"Expected PyrOx, got {context.detected_class}"
    assert len(context.ligands) > 0, "No ligands retrieved for PyrOx query"
    print(f"  Formatted context (first 300 chars):")
    print(f"    {context.formatted_context[:300]}...")
    print(f"  [PASS] Property-focused query works")

    # Test query about reductive coupling
    print("\n  --- Query: 'What ligand is best for reductive coupling of vinyl triflates?' ---")
    context2 = rag.retrieve_context("What ligand is best for reductive coupling of vinyl triflates?")
    scores2 = rag.analyze_query("What ligand is best for reductive coupling of vinyl triflates?")
    print(f"  Intent scores: {scores2}")
    print(f"  Retrieved: {len(context2.ligands)} ligands, {len(context2.reactions)} reactions")
    if context2.formatted_context:
        print(f"  Formatted context (first 300 chars):")
        print(f"    {context2.formatted_context[:300]}...")
    print(f"  [PASS] Reaction-focused query works")

    # Test query with no DB match
    print("\n  --- Query: 'Tell me about quantum computing' ---")
    context3 = rag.retrieve_context("Tell me about quantum computing")
    print(f"  Retrieved: {len(context3.ligands)} ligands, {len(context3.reactions)} reactions")
    print(f"  Formatted context empty: {not context3.formatted_context}")
    print(f"  [PASS] No-match query returns empty context")


def test_rag_prompt_enhancement():
    print("\n" + "=" * 60)
    print("TEST 8: RAG Prompt Enhancement")
    print("=" * 60)

    rag = get_ral_rag()
    enhanced = rag.build_enhanced_prompt(
        "Compare the electrophilicity of Bipy and Phen ligands",
        system_prompt="You are RAL-Bot.",
    )

    assert "Bipy" in enhanced or "bipy" in enhanced.lower(), "Enhanced prompt missing Bipy data"
    assert "HOMO" in enhanced or "LUMO" in enhanced, "Enhanced prompt missing electronic data"
    print(f"  Enhanced prompt length: {len(enhanced)} chars")
    print(f"  Contains ligand data: YES")
    print(f"  Contains electronic descriptors: YES")
    print(f"  [PASS] Prompt enhancement works")


def test_ligand_info_response():
    print("\n" + "=" * 60)
    print("TEST 9: Ligand Info Response")
    print("=" * 60)

    rag = get_ral_rag()
    resp = rag.get_ligand_info_response("PyrOx")
    assert resp is not None, "No ligand info returned"
    assert "HOMO" in resp, "Response missing HOMO"
    assert "Gap" in resp, "Response missing Gap"
    print(f"  Response (first 300 chars):")
    print(f"    {resp[:300]}...")
    print(f"  [PASS] Ligand info response works")


def test_similarity_engine():
    print("\n" + "=" * 60)
    print("TEST 10: Similarity Engine (UMAP/PCA)")
    print("=" * 60)

    from modules.ral_similarity import get_similarity_engine

    engine = get_similarity_engine()
    assert engine._fitted, "Similarity engine not fitted!"

    # Check method
    method = engine._method
    print(f"  Method: {method}")
    assert method in ('umap', 'pca'), f"Unexpected method: {method}"
    print(f"  Components: {engine._n_components_used}")
    print(f"  Ligands fitted: {len(engine._ligand_names)}")

    # Method info
    info = engine.get_method_info()
    print(f"  Method info: {info}")
    assert info['fitted'] is True
    assert info['n_ligands'] == 238
    assert info['n_components'] > 0
    if method == 'umap':
        assert 'umap_params' in info
        print(f"  UMAP params: {info['umap_params']}")
    print(f"  [PASS] Engine fitted with {method}")

    # Embedding data for visualisation
    embed_data = engine.get_embedding_data()
    assert 'points' in embed_data
    assert len(embed_data['points']) == 238
    assert embed_data['method'] == method
    print(f"  Embedding data: {len(embed_data['points'])} points, method={embed_data['method']}")
    print(f"  [PASS] Embedding data available")

    # PCA loadings (always computed as supplementary analysis)
    loadings = engine.get_pca_loadings()
    assert 'loadings' in loadings
    assert len(loadings['loadings']) > 0
    print(f"  PCA loadings: {len(loadings['loadings'])} PCs")
    print(f"  [PASS] PCA loadings available")


def test_similarity_search():
    print("\n" + "=" * 60)
    print("TEST 11: Similarity Search (KNN)")
    print("=" * 60)

    from modules.ral_similarity import get_similarity_engine

    engine = get_similarity_engine()

    # Find similar ligands to the first Bipy ligand
    query_name = None
    for i, name in enumerate(engine._ligand_names):
        if engine._ligand_classes[i] == 'Bipy':
            query_name = name
            break

    assert query_name is not None, "Could not find a Bipy ligand"
    print(f"  Query ligand: {query_name}")

    similar = engine.find_similar(query_name, k=5)
    assert len(similar) > 0, "No similar ligands found"
    print(f"  Top 5 similar ligands:")
    for s in similar:
        print(f"    - {s.name} ({s.ligand_class}): "
              f"dist={s.distance:.4f}, cosine={s.cosine_similarity:.4f}")
        assert s.embedding_coords is not None
        assert len(s.embedding_coords) > 0
    print(f"  [PASS] Similarity search returns results")

    # Verify nearest neighbour is closer than farthest
    assert similar[0].distance <= similar[-1].distance, \
        "Results not sorted by distance"
    print(f"  [PASS] Results sorted by distance")


def test_similarity_recommend():
    print("\n" + "=" * 60)
    print("TEST 12: Similarity Recommendations (with filters)")
    print("=" * 60)

    from modules.ral_similarity import get_similarity_engine

    engine = get_similarity_engine()

    # Find a Phen ligand to test with
    query_name = None
    for i, name in enumerate(engine._ligand_names):
        if engine._ligand_classes[i] == 'Phen':
            query_name = name
            break

    assert query_name is not None, "No Phen ligand found"
    print(f"  Query: {query_name} (Phen)")

    # Same class only
    same = engine.recommend_for_ligand(query_name, k=3, same_class_only=True)
    print(f"  Same-class recommendations ({len(same)}):")
    for s in same:
        print(f"    - {s.name} ({s.ligand_class})")
        assert s.ligand_class == 'Phen', f"Expected Phen, got {s.ligand_class}"
    print(f"  [PASS] Same-class filter works")

    # Different class only
    diff = engine.recommend_for_ligand(query_name, k=3, different_class_only=True)
    print(f"  Different-class recommendations ({len(diff)}):")
    for s in diff:
        print(f"    - {s.name} ({s.ligand_class})")
        assert s.ligand_class != 'Phen', f"Expected not Phen, got {s.ligand_class}"
    print(f"  [PASS] Different-class filter works")


def test_similarity_clustering():
    print("\n" + "=" * 60)
    print("TEST 13: KMeans Clustering")
    print("=" * 60)

    from modules.ral_similarity import get_similarity_engine

    engine = get_similarity_engine()
    assert engine._cluster_labels is not None, "Clustering not fitted"

    clusters = engine.get_all_clusters()
    assert len(clusters) > 0, "No clusters found"
    print(f"  {len(clusters)} clusters:")
    for c in clusters[:4]:
        print(f"    Cluster {c.cluster_id}: {c.ligand_count} ligands, "
              f"classes={c.class_distribution}")

    # Check that clusters have ligands
    total_in_clusters = sum(c.ligand_count for c in clusters)
    assert total_in_clusters == 238, f"Expected 238 in clusters, got {total_in_clusters}"

    # Get members of first cluster
    members = engine.get_cluster_members(clusters[0].cluster_id)
    assert len(members) == clusters[0].ligand_count
    assert 'embedding_coords' in members[0]
    print(f"  [PASS] Clustering works correctly")


def test_rag_with_similarity():
    print("\n" + "=" * 60)
    print("TEST 14: RAG with Similarity Recommendations")
    print("=" * 60)

    rag = get_ral_rag()

    # Query that triggers recommendation
    context = rag.retrieve_context(
        "Recommend a ligand similar to bipyridine for reductive coupling"
    )
    scores = rag.analyze_query(
        "Recommend a ligand similar to bipyridine for reductive coupling"
    )

    print(f"  Intent scores: {scores}")
    print(f"  Recommendation score: {scores['recommendation']:.2f}")

    if context.formatted_context:
        # Check if similarity section is present
        if 'Similar Ligand Recommendations' in context.formatted_context:
            method = rag._sim_method.upper() if hasattr(rag, '_sim_method') else 'UMAP'
            print(f"  Method used: {method}")
            assert method in ('UMAP', 'PCA'), f"Unexpected method: {method}"

            # Extract the similarity section
            sim_section = context.formatted_context[
                context.formatted_context.index('Similar Ligand Recommendations'):
            ]
            print(f"  Similarity section (first 400 chars):")
            print(f"    {sim_section[:400]}...")
            print(f"  [PASS] Similarity recommendations in RAG context")
        else:
            print(f"  [INFO] No similarity section (may need higher recommendation score)")
            print(f"  [PASS] RAG context generated without similarity")
    else:
        print(f"  [INFO] No context generated")
        print(f"  [PASS] Test completed")


if __name__ == '__main__':
    print("RAL Database + RAG + Similarity Integration Test Suite\n")
    test_database_load()
    test_ligand_search()
    test_ligand_classes()
    test_class_comparison()
    test_reaction_search()
    test_combined_search()
    test_rag_retrieval()
    test_rag_prompt_enhancement()
    test_ligand_info_response()
    test_similarity_engine()
    test_similarity_search()
    test_similarity_recommend()
    test_similarity_clustering()
    test_rag_with_similarity()
    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)