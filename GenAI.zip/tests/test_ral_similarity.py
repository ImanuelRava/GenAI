"""
Integration test for the Ligand Similarity Engine + RAG integration.
Tests PCA fitting, KNN search, clustering, and RAG recommendation flow.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'backend'))

from modules.ral_database import get_ral_database
from modules.ral_similarity import get_similarity_engine, LigandSimilarityEngine
from modules.ral_rag import get_ral_rag


def test_pca_fitting():
    print("=" * 60)
    print("TEST 1: PCA Fitting")
    print("=" * 60)

    engine = get_similarity_engine()
    assert engine._fitted, "Engine not fitted!"
    print(f"  PCA components used: {engine._n_components_used}")
    print(f"  Variance explained: {sum(engine._explained_variance):.1%}")
    for i, vr in enumerate(engine._explained_variance):
        print(f"    PC{i+1}: {vr:.1%}")
    print(f"  Total ligands in PCA space: {len(engine._ligand_names)}")
    assert engine._n_components_used >= 2
    assert sum(engine._explained_variance) >= 0.85
    print(f"  [PASS] PCA fitted successfully")


def test_similarity_search():
    print("\n" + "=" * 60)
    print("TEST 2: KNN Similarity Search")
    print("=" * 60)

    engine = get_similarity_engine()

    # Find similar to PyrOx (the parent ligand)
    results = engine.find_similar("PyrOx", k=5)
    print(f"  Similar to 'PyrOx': {len(results)} results")
    assert len(results) > 0, "No similar ligands found"
    for r in results[:3]:
        print(f"    - {r.name} ({r.ligand_class}) "
              f"dist={r.distance:.4f}, cos={r.cosine_similarity:.4f}")
    # The most similar should be another PyrOx
    assert results[0].ligand_class == 'PyrOx', \
        f"Expected PyrOx, got {results[0].ligand_class}"
    print(f"  [PASS] KNN search returns class neighbours")

    # Find similar to a Phen ligand
    results2 = engine.find_similar("2-Br-phen", k=5)
    print(f"\n  Similar to '2-Br-phen': {len(results2)} results")
    for r in results2[:3]:
        print(f"    - {r.name} ({r.ligand_class}) "
              f"dist={r.distance:.4f}, cos={r.cosine_similarity:.4f}")
    print(f"  [PASS] Phen similarity works")

    # Same-class-only filter
    results3 = engine.recommend_for_ligand("2-Br-phen", k=5, same_class_only=True)
    print(f"\n  Same-class only (Phen): {len(results3)} results")
    for r in results3:
        assert r.ligand_class == 'Phen', f"Got {r.ligand_class}, expected Phen"
    print(f"  [PASS] Same-class filter works")

    # Different-class filter
    results4 = engine.recommend_for_ligand("2-Br-phen", k=5, different_class_only=True)
    print(f"  Different-class only: {len(results4)} results")
    for r in results4:
        assert r.ligand_class != 'Phen', f"Got {r.ligand_class}, expected not Phen"
    print(f"  [PASS] Different-class filter works")


def test_clustering():
    print("\n" + "=" * 60)
    print("TEST 3: KMeans Clustering")
    print("=" * 60)

    engine = get_similarity_engine()
    assert engine._cluster_labels is not None, "Clustering not fitted"
    print(f"  Number of clusters: {engine._n_clusters}")

    clusters = engine.get_all_clusters()
    print(f"  Cluster summary:")
    for c in clusters:
        cls_str = ", ".join(f"{k}:{v}" for k, v in sorted(c.class_distribution.items()))
        print(f"    Cluster {c.cluster_id}: {c.ligand_count} ligands [{cls_str}]")
    assert len(clusters) == engine._n_clusters
    print(f"  [PASS] Clustering works")


def test_pca_visualization_data():
    print("\n" + "=" * 60)
    print("TEST 4: PCA Visualization Data")
    print("=" * 60)

    engine = get_similarity_engine()
    data = engine.get_pca_data()
    assert 'points' in data
    assert len(data['points']) == 238
    assert 'pca1' in data['points'][0]
    assert 'class' in data['points'][0]
    print(f"  Points: {len(data['points'])}")
    print(f"  Components: {data['n_components']}")
    print(f"  Variance: {data['total_variance_explained']:.1%}")
    print(f"  Sample: {data['points'][0]}")
    print(f"  [PASS] PCA viz data works")


def test_pca_loadings():
    print("\n" + "=" * 60)
    print("TEST 5: PCA Loadings (Feature Importance)")
    print("=" * 60)

    engine = get_similarity_engine()
    loadings = engine.get_pca_loadings()
    assert 'loadings' in loadings

    for pc in loadings['loadings']:
        # Find top 2 features
        sorted_feats = sorted(pc['loadings'].items(), key=lambda x: abs(x[1]), reverse=True)
        top2 = sorted_feats[:2]
        print(f"  {pc['pc']} ({pc['variance_explained']:.1%}): "
              f"top features = {top2[0][0]} ({top2[0][1]:+.3f}), "
              f"{top2[1][0]} ({top2[1][1]:+.3f})")
    print(f"  [PASS] PCA loadings work")


def test_rag_with_recommendations():
    print("\n" + "=" * 60)
    print("TEST 6: RAG with Similarity Recommendations")
    print("=" * 60)

    rag = get_ral_rag()

    # Query that should trigger recommendation logic
    query = "What ligand would you recommend for reductive coupling of vinyl triflates?"
    context = rag.retrieve_context(query)
    scores = rag.analyze_query(query)

    print(f"  Query: {query}")
    print(f"  Intent scores: {scores}")
    print(f"  Recommendation score: {scores.get('recommendation', 0):.2f}")
    print(f"  Detected class: {context.detected_class}")
    print(f"  Ligands: {len(context.ligands)}, Reactions: {len(context.reactions)}")

    # Check if similarity recommendations appear in context
    has_similar_section = "Similar Ligand Recommendations" in context.formatted_context
    print(f"  Has similarity section: {has_similar_section}")

    if has_similar_section:
        # Extract and show the similar ligands
        lines = context.formatted_context.split("\n")
        in_similar = False
        for line in lines:
            if "Similar Ligand" in line:
                in_similar = True
            if in_similar:
                print(f"    {line}")
                if "PCA-reduced" in line:
                    break
    else:
        print("  (No similarity section — this is OK if no DB match found)")

    print(f"  [PASS] RAG recommendation flow completes")


def test_rag_explicit_recommendation():
    print("\n" + "=" * 60)
    print("TEST 7: RAG with Explicit 'suggest' keyword")
    print("=" * 60)

    rag = get_ral_rag()

    query = "Suggest an alternative ligand similar to bipyridine for nickel catalysis"
    context = rag.retrieve_context(query)
    scores = rag.analyze_query(query)

    print(f"  Query: {query}")
    print(f"  Recommendation score: {scores.get('recommendation', 0):.2f}")
    print(f"  Reaction score: {scores.get('reactions', 0):.2f}")
    print(f"  Formatted context length: {len(context.formatted_context)}")

    has_similar = "Similar Ligand Recommendations" in context.formatted_context
    print(f"  Has similarity section: {has_similar}")

    if has_similar:
        lines = context.formatted_context.split("\n")
        in_similar = False
        for line in lines:
            if "Similar Ligand" in line:
                in_similar = True
            if in_similar:
                print(f"    {line}")
                if "PCA-reduced" in line:
                    break

    print(f"  [PASS] Explicit recommendation query works")


if __name__ == '__main__':
    print("RAL Similarity Engine + RAG Integration Test Suite\n")
    test_pca_fitting()
    test_similarity_search()
    test_clustering()
    test_pca_visualization_data()
    test_pca_loadings()
    test_rag_with_recommendations()
    test_rag_explicit_recommendation()
    print("\n" + "=" * 60)
    print("ALL TESTS PASSED!")
    print("=" * 60)