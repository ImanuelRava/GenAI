"""
ChemExtract AI - Advanced PDF Extractor for Chemical Reaction Data

This module provides comprehensive chemical information extraction from PDFs,
using AI-powered multimodal analysis including:
- Text extraction with chemical entity recognition
- Image analysis for reaction schemes, structures, and tables
- Molecular formula and SMILES notation extraction
- Reaction condition parsing

Uses LLM Vision models for intelligent extraction when specialized
chemistry models are not available.
"""

import os
import re
import json
import logging
import base64
import tempfile
from typing import List, Dict, Any, Optional, Tuple

logger = logging.getLogger(__name__)

# Try to import PDF libraries
try:
    from pdf2image import convert_from_path
    HAS_PDF2IMAGE = True
except ImportError:
    HAS_PDF2IMAGE = False
    logger.info("[ChemExtract] pdf2image not available, using PyMuPDF fallback")

try:
    import fitz  # PyMuPDF
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False
    logger.warning("[ChemExtract] PyMuPDF not available")

try:
    import pypdf
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False

try:
    import pdfplumber
    HAS_PDFPLUMBER = True
except ImportError:
    HAS_PDFPLUMBER = False


# ============================================================
# CHEMISTRY-SPECIFIC PROMPTS
# ============================================================

SYSTEM_PROMPT_CHEMICAL_ENTITIES = """You are an expert chemist specializing in extracting chemical entities from scientific literature. 

Extract ALL chemical entities from the given text, including:
1. Chemical compounds (by name, formula, or description)
2. Reagents and starting materials
3. Products and intermediates
4. Catalysts and catalyst systems
5. Ligands (phosphines, NHCs, bipyridines, etc.)
6. Solvents
7. Additives and bases/acids

For each entity, provide:
- name: The common or IUPAC name
- smiles: SMILES notation if determinable
- formula: Molecular formula if determinable
- role: reactant, product, catalyst, ligand, solvent, reagent, additive

Return a JSON object:
{
  "entities": [
    {
      "name": "compound name",
      "smiles": "SMILES string or null",
      "formula": "molecular formula or null",
      "role": "reactant|product|catalyst|ligand|solvent|reagent|additive"
    }
  ]
}"""

SYSTEM_PROMPT_REACTION_SCHEME = """You are an expert chemist analyzing reaction scheme images from scientific papers.

Analyze the image carefully and extract:
1. All molecular structures visible (as SMILES if possible, or describe them)
2. Reaction arrows and their direction
3. Reagents and conditions written above/below arrows
4. Yields (percentages or amounts)
5. Temperature, time, pressure conditions
6. Catalyst and ligand structures
7. Any stereochemistry indicators

Return a JSON object:
{
  "reaction_schemes": [
    {
      "reactants": [{"name": "...", "smiles": "...", "structure_description": "..."}],
      "products": [{"name": "...", "smiles": "...", "structure_description": "..."}],
      "reagents": ["list of reagents"],
      "conditions": {
        "temperature": "e.g., 80°C",
        "time": "e.g., 12h",
        "solvent": "solvent name",
        "atmosphere": "N2/Ar/air",
        "other": "other conditions"
      },
      "yield": "yield value",
      "catalyst": "catalyst info",
      "ligand": "ligand info"
    }
  ],
  "description": "overall description of what's shown",
  "notes": "any additional observations"
}"""

SYSTEM_PROMPT_TABLE_EXTRACTION = """You are an expert chemist extracting data from chemistry tables in scientific papers.

Extract table data including:
1. Entry/row numbers
2. Substrate/product variations
3. Reaction conditions for each entry
4. Yields and selectivities
5. Any footnotes or special conditions

Return a JSON object:
{
  "table_type": "optimization|substrate_scope|condition_screening|other",
  "columns": ["column names"],
  "data": [
    {
      "entry": 1,
      "values": {"column_name": "value", ...}
    }
  ],
  "footnotes": ["footnote texts"],
  "general_conditions": "general reaction conditions if stated"
}"""

SYSTEM_PROMPT_COMPREHENSIVE = """You are ChemExtract AI, an expert chemistry data extraction system. Analyze the provided scientific document content and extract ALL chemical information comprehensively.

EXTRACT AND STRUCTURE:

1. **Chemical Entities**
   - All compounds mentioned (reactants, products, intermediates)
   - Catalysts and catalytic systems
   - Ligands (organophosphines, NHCs, nitrogen ligands, etc.)
   - Solvents, reagents, additives, bases, acids
   - Include SMILES and molecular formulas when determinable

2. **Reaction Information**
   - Reaction type (coupling, addition, oxidation, etc.)
   - Transformation description
   - Mechanistic insights if mentioned

3. **Reaction Conditions**
   - Temperature (value and unit)
   - Time (duration)
   - Pressure (if applicable)
   - Atmosphere (N2, Ar, air, etc.)
   - Concentration
   - Scale

4. **Outcomes**
   - Isolated yields
   - Conversions
   - Selectivities (ee, de, regioselectivity)
   - Turnover numbers/frequencies (TON/TOF)

5. **Molecular Structures**
   - SMILES strings
   - InChI if determinable
   - Molecular formulas
   - Structural features (stereocenters, functional groups)

6. **Spectral Data** (if present)
   - NMR shifts
   - MS data
   - IR peaks

Return structured JSON:
{
  "reactions": [
    {
      "id": "reaction_1",
      "type": "reaction type",
      "reactants": [{"name": "...", "smiles": "...", "formula": "..."}],
      "products": [{"name": "...", "smiles": "...", "formula": "..."}],
      "catalysts": [{"name": "...", "loading": "..."}],
      "ligands": [{"name": "..."}],
      "solvents": ["..."],
      "conditions": {
        "temperature": "...",
        "time": "...",
        "atmosphere": "...",
        "pressure": "...",
        "concentration": "..."
      },
      "outcomes": {
        "yield": "...",
        "conversion": "...",
        "selectivity": {...}
      }
    }
  ],
  "compounds": [
    {
      "name": "...",
      "smiles": "...",
      "formula": "...",
      "mw": "...",
      "role": "..."
    }
  ],
  "experimental_procedures": ["..."],
  "characterization_data": {...}
}"""


# ============================================================
# PDF CONVERSION UTILITIES
# ============================================================

def pdf_to_images(file_path: str, dpi: int = 150, max_pages: int = 10) -> List[Tuple[int, str]]:
    """
    Convert PDF pages to base64-encoded images.
    
    Returns list of tuples: [(page_number, base64_image), ...]
    """
    images = []
    
    if HAS_PDF2IMAGE:
        try:
            pil_images = convert_from_path(file_path, dpi=dpi)
            for i, img in enumerate(pil_images[:max_pages]):
                import io
                buffer = io.BytesIO()
                img.save(buffer, format='PNG')
                base64_image = base64.b64encode(buffer.getvalue()).decode('utf-8')
                images.append((i + 1, base64_image))
            
            logger.info(f"[ChemExtract] Converted {len(images)} pages using pdf2image")
            return images
        except Exception as e:
            logger.warning(f"[ChemExtract] pdf2image failed: {e}")
    
    if HAS_PYMUPDF:
        try:
            doc = fitz.open(file_path)
            for page_num in range(min(len(doc), max_pages)):
                page = doc[page_num]
                mat = fitz.Matrix(dpi / 72, dpi / 72)
                pix = page.get_pixmap(matrix=mat)
                img_data = pix.tobytes("png")
                base64_image = base64.b64encode(img_data).decode('utf-8')
                images.append((page_num + 1, base64_image))
            
            logger.info(f"[ChemExtract] Converted {len(images)} pages using PyMuPDF")
            return images
        except Exception as e:
            logger.error(f"[ChemExtract] PyMuPDF failed: {e}")
    
    raise ImportError("No PDF image conversion library available. Install pdf2image or PyMuPDF.")


def extract_text_from_pdf(file_path: str) -> Tuple[str, Dict]:
    """
    Extract text content from PDF.
    
    Returns (text, metadata) tuple.
    """
    text = ""
    metadata = {"pages": 0, "method": None}
    
    if HAS_PYPDF:
        try:
            reader = pypdf.PdfReader(file_path)
            metadata["pages"] = len(reader.pages)
            metadata["method"] = "pypdf"
            
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n\n"
            
            if text.strip():
                return text, metadata
        except Exception as e:
            logger.warning(f"[ChemExtract] pypdf failed: {e}")
    
    if HAS_PDFPLUMBER:
        try:
            with pdfplumber.open(file_path) as pdf:
                metadata["pages"] = len(pdf.pages)
                metadata["method"] = "pdfplumber"
                
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n\n"
            
            return text, metadata
        except Exception as e:
            logger.error(f"[ChemExtract] pdfplumber failed: {e}")
    
    if HAS_PYMUPDF:
        try:
            doc = fitz.open(file_path)
            metadata["pages"] = len(doc)
            metadata["method"] = "pymupdf"
            
            for page in doc:
                text += page.get_text() + "\n\n"
            
            return text, metadata
        except Exception as e:
            logger.error(f"[ChemExtract] PyMuPDF text extraction failed: {e}")
    
    raise ImportError("No PDF text extraction library available. Install pypdf, pdfplumber, or PyMuPDF.")


# ============================================================
# LLM VISION INTEGRATION
# ============================================================

def call_vision_llm(
    base64_image: str,
    provider: str,
    model: str,
    api_key: str,
    system_prompt: str,
    user_message: str
) -> Optional[Dict]:
    """Call a vision-capable LLM to extract data from an image."""
    
    try:
        if provider == 'deepseek':
            return _call_deepseek_vision(base64_image, model, api_key, system_prompt, user_message)
        elif provider == 'openai':
            return _call_openai_vision(base64_image, model, api_key, system_prompt, user_message)
        elif provider == 'gemini':
            return _call_gemini_vision(base64_image, model, api_key, system_prompt, user_message)
        elif provider == 'anthropic':
            return _call_anthropic_vision(base64_image, model, api_key, system_prompt, user_message)
        else:
            logger.error(f"[ChemExtract] Unsupported vision provider: {provider}")
            return None
    except Exception as e:
        logger.error(f"[ChemExtract] Vision LLM call failed: {e}")
        return None


def _parse_json_response(content: str) -> Optional[Dict]:
    """Parse JSON from LLM response."""
    if not content:
        return None
    
    try:
        # Try to find JSON in the response
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            return json.loads(json_match.group(0))
    except json.JSONDecodeError as e:
        logger.warning(f"[ChemExtract] JSON parse error: {e}")
    
    return None


def _call_deepseek_vision(base64_image: str, model: str, api_key: str, system_prompt: str, user_message: str) -> Optional[Dict]:
    """Call DeepSeek Vision API."""
    import requests
    
    url = "https://api.deepseek.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_message},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                ]
            }
        ],
        "max_tokens": 4000,
        "temperature": 0.1
    }
    
    response = requests.post(url, headers=headers, json=payload, timeout=120)
    if response.status_code == 200:
        content = response.json()['choices'][0]['message']['content']
        return _parse_json_response(content)
    
    logger.error(f"[ChemExtract] DeepSeek API error: {response.status_code}")
    return None


def _call_openai_vision(base64_image: str, model: str, api_key: str, system_prompt: str, user_message: str) -> Optional[Dict]:
    """Call OpenAI GPT-4 Vision API."""
    import openai
    
    client = openai.OpenAI(api_key=api_key)
    
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_message},
                    {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}", "detail": "high"}}
                ]
            }
        ],
        max_tokens=4000,
        temperature=0.1
    )
    
    return _parse_json_response(response.choices[0].message.content)


def _call_gemini_vision(base64_image: str, model: str, api_key: str, system_prompt: str, user_message: str) -> Optional[Dict]:
    """Call Google Gemini Vision API."""
    import google.generativeai as genai
    import PIL.Image
    import io
    
    genai.configure(api_key=api_key)
    model_obj = genai.GenerativeModel(model)
    
    image_data = base64.b64decode(base64_image)
    image = PIL.Image.open(io.BytesIO(image_data))
    
    response = model_obj.generate_content([system_prompt, "\n\n", user_message, image])
    return _parse_json_response(response.text)


def _call_anthropic_vision(base64_image: str, model: str, api_key: str, system_prompt: str, user_message: str) -> Optional[Dict]:
    """Call Anthropic Claude Vision API."""
    import anthropic
    
    client = anthropic.Anthropic(api_key=api_key)
    
    response = client.messages.create(
        model=model,
        max_tokens=4000,
        system=system_prompt,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": base64_image}},
                    {"type": "text", "text": user_message}
                ]
            }
        ]
    )
    
    return _parse_json_response(response.content[0].text)


# ============================================================
# MAIN EXTRACTOR CLASS
# ============================================================

class ChemExtractAI:
    """
    ChemExtract AI - Advanced Chemistry Data Extraction System
    
    Provides comprehensive extraction of chemical information from PDFs:
    - Text analysis for chemical entities and reactions
    - Image analysis for reaction schemes and structures
    - Table extraction for optimization data
    - SMILES and molecular formula recognition
    """
    
    def __init__(self, llm_provider: str = 'deepseek', api_key: str = None, model: str = None):
        """
        Initialize the extractor.
        
        Args:
            llm_provider: LLM provider ('deepseek', 'openai', 'gemini', 'anthropic')
            api_key: API key for the LLM provider
            model: Specific model to use (optional, uses default if not specified)
        """
        self.llm_provider = llm_provider
        self.api_key = api_key
        self.model = model
        
        # Vision-capable providers
        self.vision_providers = ['deepseek', 'openai', 'gemini', 'anthropic']
        
        # Default models per provider
        self.default_models = {
            'deepseek': 'deepseek-chat',
            'openai': 'gpt-4o',
            'gemini': 'gemini-2.0-flash',
            'anthropic': 'claude-3-5-sonnet-20241022'
        }
        
        if not self.model:
            self.model = self.default_models.get(llm_provider)
    
    def extract_from_pdf(
        self,
        pdf_path: str,
        extract_images: bool = True,
        extract_text: bool = True,
        max_pages: int = 10
    ) -> Dict[str, Any]:
        """
        Perform comprehensive extraction from a PDF.
        
        Args:
            pdf_path: Path to the PDF file
            extract_images: Whether to analyze images with vision AI
            extract_text: Whether to extract and analyze text
            max_pages: Maximum number of pages to process
            
        Returns:
            Dictionary containing all extracted chemical data
        """
        result = {
            "reactions": [],
            "compounds": [],
            "figures": [],
            "tables": [],
            "text_content": "",
            "metadata": {
                "pages_processed": 0,
                "extraction_method": "chemextract_ai",
                "provider": self.llm_provider,
                "model": self.model
            }
        }
        
        # Extract text
        if extract_text:
            try:
                text, text_meta = extract_text_from_pdf(pdf_path)
                result["text_content"] = text
                result["metadata"]["pages"] = text_meta.get("pages", 0)
                result["metadata"]["text_method"] = text_meta.get("method")
                
                # Analyze text for chemical data
                if text.strip():
                    text_data = self._analyze_text(text)
                    if text_data:
                        result["reactions"].extend(text_data.get("reactions", []))
                        result["compounds"].extend(text_data.get("compounds", []))
            except Exception as e:
                logger.error(f"[ChemExtract] Text extraction failed: {e}")
        
        # Extract and analyze images
        if extract_images and self.llm_provider in self.vision_providers:
            try:
                page_images = pdf_to_images(pdf_path, dpi=150, max_pages=max_pages)
                result["metadata"]["pages_processed"] = len(page_images)
                
                for page_num, base64_img in page_images:
                    # Extract reaction schemes
                    scheme_data = self._extract_from_image(
                        base64_img, 
                        extraction_type="reactions",
                        page_number=page_num
                    )
                    if scheme_data:
                        result["reactions"].extend(scheme_data.get("reaction_schemes", []))
                        result["figures"].append({
                            "page": page_num,
                            "type": "reaction_scheme",
                            "data": scheme_data
                        })
                    
                    # Extract tables
                    table_data = self._extract_from_image(
                        base64_img,
                        extraction_type="tables",
                        page_number=page_num
                    )
                    if table_data and table_data.get("data"):
                        result["tables"].append({
                            "page": page_num,
                            "type": table_data.get("table_type", "unknown"),
                            "data": table_data.get("data", []),
                            "columns": table_data.get("columns", [])
                        })
                        
            except Exception as e:
                logger.error(f"[ChemExtract] Image extraction failed: {e}")
        
        # Deduplicate compounds
        seen_compounds = set()
        unique_compounds = []
        for compound in result["compounds"]:
            key = compound.get("name", "") or compound.get("smiles", "")
            if key and key not in seen_compounds:
                seen_compounds.add(key)
                unique_compounds.append(compound)
        result["compounds"] = unique_compounds
        
        return result
    
    def _analyze_text(self, text: str) -> Optional[Dict]:
        """Analyze text for chemical data using LLM."""
        # Use text-based LLM call
        try:
            if self.llm_provider == 'deepseek':
                return self._call_deepseek_text(text)
            elif self.llm_provider == 'openai':
                return self._call_openai_text(text)
            elif self.llm_provider == 'gemini':
                return self._call_gemini_text(text)
            elif self.llm_provider == 'anthropic':
                return self._call_anthropic_text(text)
            else:
                # Generic OpenAI-compatible API call
                return self._call_generic_text(text)
        except Exception as e:
            logger.error(f"[ChemExtract] Text analysis failed: {e}")
            return None
    
    def _extract_from_image(
        self, 
        base64_image: str, 
        extraction_type: str = "reactions",
        page_number: int = 1
    ) -> Optional[Dict]:
        """Extract data from an image using vision LLM."""
        
        if extraction_type == "reactions":
            system_prompt = SYSTEM_PROMPT_REACTION_SCHEME
            user_message = f"Analyze page {page_number} of this scientific document. Extract all reaction schemes, molecular structures, and chemical transformations visible."
        elif extraction_type == "tables":
            system_prompt = SYSTEM_PROMPT_TABLE_EXTRACTION
            user_message = f"Analyze page {page_number}. Extract any chemistry-related tables (optimization tables, substrate scope, condition screening)."
        else:
            system_prompt = SYSTEM_PROMPT_REACTION_SCHEME
            user_message = f"Extract all chemical information from page {page_number}."
        
        return call_vision_llm(
            base64_image,
            self.llm_provider,
            self.model,
            self.api_key,
            system_prompt,
            user_message
        )
    
    def _call_deepseek_text(self, text: str) -> Optional[Dict]:
        """Call DeepSeek for text analysis."""
        import requests
        
        url = "https://api.deepseek.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT_COMPREHENSIVE},
                {"role": "user", "content": f"Extract all chemical information from this text:\n\n{text[:8000]}"}
            ],
            "max_tokens": 4000,
            "temperature": 0.1
        }
        
        response = requests.post(url, headers=headers, json=payload, timeout=120)
        if response.status_code == 200:
            content = response.json()['choices'][0]['message']['content']
            return _parse_json_response(content)
        return None
    
    def _call_openai_text(self, text: str) -> Optional[Dict]:
        """Call OpenAI for text analysis."""
        import openai
        
        client = openai.OpenAI(api_key=self.api_key)
        response = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT_COMPREHENSIVE},
                {"role": "user", "content": f"Extract all chemical information from this text:\n\n{text[:8000]}"}
            ],
            max_tokens=4000,
            temperature=0.1
        )
        
        return _parse_json_response(response.choices[0].message.content)
    
    def _call_gemini_text(self, text: str) -> Optional[Dict]:
        """Call Gemini for text analysis."""
        import google.generativeai as genai
        
        genai.configure(api_key=self.api_key)
        model = genai.GenerativeModel(self.model)
        
        response = model.generate_content([
            SYSTEM_PROMPT_COMPREHENSIVE,
            f"\n\nExtract all chemical information from this text:\n\n{text[:8000]}"
        ])
        
        return _parse_json_response(response.text)
    
    def _call_anthropic_text(self, text: str) -> Optional[Dict]:
        """Call Anthropic for text analysis."""
        import anthropic
        
        client = anthropic.Anthropic(api_key=self.api_key)
        response = client.messages.create(
            model=self.model,
            max_tokens=4000,
            system=SYSTEM_PROMPT_COMPREHENSIVE,
            messages=[
                {"role": "user", "content": f"Extract all chemical information from this text:\n\n{text[:8000]}"}
            ]
        )
        
        return _parse_json_response(response.content[0].text)
    
    def _call_generic_text(self, text: str) -> Optional[Dict]:
        """Generic OpenAI-compatible API call."""
        import requests
        
        # This assumes an OpenAI-compatible endpoint
        url = f"https://api.{self.llm_provider}.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT_COMPREHENSIVE},
                {"role": "user", "content": f"Extract all chemical information from this text:\n\n{text[:8000]}"}
            ],
            "max_tokens": 4000,
            "temperature": 0.1
        }
        
        response = requests.post(url, headers=headers, json=payload, timeout=120)
        if response.status_code == 200:
            content = response.json()['choices'][0]['message']['content']
            return _parse_json_response(content)
        return None


# ============================================================
# CONVENIENCE FUNCTION
# ============================================================

def extract_chemical_data_from_pdf(
    pdf_path: str,
    llm_provider: str = 'deepseek',
    api_key: str = None,
    model: str = None,
    max_pages: int = 10,
    extract_images: bool = True,
    extract_text: bool = True
) -> Dict[str, Any]:
    """
    Convenience function to extract chemical data from a PDF.
    
    Args:
        pdf_path: Path to the PDF file
        llm_provider: LLM provider ('deepseek', 'openai', 'gemini', 'anthropic')
        api_key: API key for the LLM provider
        model: Specific model to use (optional)
        max_pages: Maximum pages to process
        extract_images: Whether to analyze images
        extract_text: Whether to extract text
        
    Returns:
        Dictionary containing extracted chemical data
    """
    extractor = ChemExtractAI(
        llm_provider=llm_provider,
        api_key=api_key,
        model=model
    )
    
    return extractor.extract_from_pdf(
        pdf_path,
        extract_images=extract_images,
        extract_text=extract_text,
        max_pages=max_pages
    )


# ============================================================
# CLI ENTRY POINT
# ============================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("ChemExtract AI - Chemical Data Extraction Tool")
        print("Usage: python chemextract_extractor.py <pdf_path> [provider] [api_key]")
        print("\nProviders: deepseek, openai, gemini, anthropic")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    provider = sys.argv[2] if len(sys.argv) > 2 else 'deepseek'
    api_key = sys.argv[3] if len(sys.argv) > 3 else os.environ.get(f'{provider.upper()}_API_KEY')
    
    if not api_key:
        print(f"Error: No API key provided. Set {provider.upper()}_API_KEY environment variable or pass as argument.")
        sys.exit(1)
    
    print(f"Extracting from: {pdf_path}")
    print(f"Provider: {provider}")
    
    result = extract_chemical_data_from_pdf(
        pdf_path,
        llm_provider=provider,
        api_key=api_key
    )
    
    print("\n=== Extraction Results ===")
    print(f"Reactions found: {len(result.get('reactions', []))}")
    print(f"Compounds found: {len(result.get('compounds', []))}")
    print(f"Tables found: {len(result.get('tables', []))}")
    print(f"\nFull results saved to extraction_result.json")
    
    with open("extraction_result.json", "w") as f:
        json.dump(result, f, indent=2, default=str)
