"""
Data Extraction Route for GenAI Research Platform
Extracts chemical reaction data from scientific text/PDF using LLM
Supports both text extraction and image analysis for PDFs
"""

import os
import re
import json
import logging
import tempfile
import base64
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename

logger = logging.getLogger(__name__)

data_extraction_bp = Blueprint('data_extraction', __name__)

# Default models for each provider
PROVIDER_DEFAULT_MODELS = {
    'deepseek': 'deepseek-chat',
    'openai': 'gpt-4o-mini',
    'gemini': 'gemini-2.0-flash',
    'groq': 'llama-3.3-70b-versatile',
    'ollama': 'llama3',
    'anthropic': 'claude-3-5-sonnet-20241022',
    'zhipu': 'glm-4-flash',
}

# Vision-capable models for image analysis
# Note: DeepSeek VL model may require special access or different endpoint
VISION_CAPABLE_MODELS = {
    'deepseek': 'deepseek-chat',  # DeepSeek has vision support in their chat model
    'openai': 'gpt-4o',  # GPT-4o has vision
    'gemini': 'gemini-2.0-flash',  # Gemini has vision
    'anthropic': 'claude-3-5-sonnet-20241022',  # Claude has vision
}

# Available LLM models for extraction (for backwards compatibility)
AVAILABLE_MODELS = [
    {"id": "deepseek-chat", "name": "DeepSeek Chat", "provider": "DeepSeek", "description": "Fast and efficient"},
    {"id": "deepseek-reasoner", "name": "DeepSeek Reasoner", "provider": "DeepSeek", "description": "Enhanced reasoning"},
    {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI", "description": "Vision capable"},
    {"id": "gpt-4o-mini", "name": "GPT-4o Mini", "provider": "OpenAI", "description": "Fast and cheap"},
    {"id": "gemini-2.0-flash", "name": "Gemini 2.0 Flash", "provider": "Google", "description": "Vision capable"},
    {"id": "claude-3-5-sonnet-20241022", "name": "Claude 3.5 Sonnet", "provider": "Anthropic", "description": "Vision capable"},
    {"id": "glm-4-flash", "name": "GLM-4-Flash", "provider": "Zhipu AI", "description": "Fast and efficient"},
]

SYSTEM_PROMPT = """You are an expert chemist specializing in extracting structured chemical reaction data from scientific literature. Extract all relevant chemical information from the given text and return it in a structured JSON format.

Extract the following information:
1. Reactants - starting materials in the reaction
2. Products - compounds formed by the reaction
3. Catalysts - substances that speed up the reaction without being consumed
4. Ligands - molecules that bind to central metal atoms
5. Solvents - substances that dissolve reactants
6. Reaction conditions (temperature, time, pressure, atmosphere)
7. Yields - amount of product obtained (with percentage if available)
8. Selectivity - if mentioned (enantioselectivity, diastereoselectivity, etc.)
9. Reaction type - classification of the reaction
10. Mechanisms - proposed or confirmed reaction mechanisms

Return ONLY a valid JSON object with this structure:
{
  "reactants": ["list of reactants"],
  "products": ["list of products"],
  "catalysts": ["list of catalysts"],
  "ligands": ["list of ligands"],
  "solvents": ["list of solvents"],
  "conditions": {
    "temperature": "e.g., 80°C",
    "time": "e.g., 12 hours",
    "pressure": "e.g., 1 atm",
    "atmosphere": "e.g., N2, Ar"
  },
  "yields": [
    {"product": "product name", "yield": "e.g., 85%"}
  ],
  "selectivity": "e.g., 95% ee",
  "reactionType": "e.g., Suzuki coupling",
  "mechanisms": ["list of mechanistic steps or pathways"]
}

If information is not found, use an empty array or null for that field. Be precise and include specific compound names, numbers, and units when available."""


def parse_extraction_result(content: str) -> dict:
    """Parse JSON from LLM response."""
    if not content:
        logger.warning("[Parse] Empty content received")
        return get_empty_result()
    
    try:
        # Try to find JSON in the response
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            result = json.loads(json_match.group(0))
            logger.info(f"[Parse] Successfully parsed JSON with keys: {list(result.keys())}")
            return result
        else:
            logger.warning("[Parse] No JSON object found in response")
    except json.JSONDecodeError as e:
        logger.warning(f"[Parse] JSON decode error: {e}")
    
    return get_empty_result()


def get_empty_result() -> dict:
    """Return an empty result structure."""
    return {
        "reactants": [],
        "products": [],
        "catalysts": [],
        "ligands": [],
        "solvents": [],
        "conditions": {},
        "yields": [],
        "mechanisms": []
    }


def extract_pdf_text(file_path: str) -> tuple:
    """Extract text from PDF file.
    
    Returns (text, metadata) tuple.
    Uses pypdf first, then falls back to pdfplumber.
    """
    text = ""
    metadata = {"pages": 0, "info": {}}
    
    # Try pypdf first
    try:
        import pypdf
        
        reader = pypdf.PdfReader(file_path)
        metadata["pages"] = len(reader.pages)
        metadata["info"] = str(reader.metadata) if reader.metadata else {}
        metadata["method"] = "pypdf"
        
        for i, page in enumerate(reader.pages):
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n\n"
                logger.debug(f"[pypdf] Page {i+1}: {len(page_text)} chars")
        
        logger.info(f"[pypdf] Extracted {len(text)} chars from {metadata['pages']} pages")
        
        if text.strip():
            return text, metadata
        
        logger.warning("[pypdf] No text extracted, trying pdfplumber...")
        
    except ImportError:
        logger.info("[pypdf] Not available, trying pdfplumber")
    except Exception as e:
        logger.warning(f"[pypdf] Error: {e}, trying pdfplumber")
    
    # Try pdfplumber as fallback
    try:
        import pdfplumber
        
        with pdfplumber.open(file_path) as pdf:
            metadata["pages"] = len(pdf.pages)
            metadata["method"] = "pdfplumber"
            
            for i, page in enumerate(pdf.pages):
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n\n"
                    logger.debug(f"[pdfplumber] Page {i+1}: {len(page_text)} chars")
        
        logger.info(f"[pdfplumber] Extracted {len(text)} chars from {metadata['pages']} pages")
        
        return text, metadata
        
    except ImportError:
        raise ImportError(
            "No PDF library available. Install pypdf or pdfplumber:\n"
            "  pip install pypdf\n"
            "  pip install pdfplumber"
        )
    except Exception as e:
        logger.error(f"[pdfplumber] Error: {e}")
        raise Exception(f"Failed to extract text from PDF: {e}")


def pdf_to_images(file_path: str, dpi: int = 150) -> list:
    """Convert PDF pages to base64-encoded images.
    
    Returns list of tuples: (page_number, base64_image)
    """
    images = []
    
    # Try pdf2image first (best quality)
    try:
        from pdf2image import convert_from_path
        
        pil_images = convert_from_path(file_path, dpi=dpi)
        for i, img in enumerate(pil_images):
            import io
            buffer = io.BytesIO()
            img.save(buffer, format='PNG')
            base64_image = base64.b64encode(buffer.getvalue()).decode('utf-8')
            images.append((i + 1, base64_image))
        
        logger.info(f"[PDF] Converted {len(images)} pages to images using pdf2image")
        return images
    except ImportError:
        logger.info("[PDF] pdf2image not available, trying PyMuPDF")
    except Exception as e:
        logger.warning(f"[PDF] pdf2image failed: {e}, trying PyMuPDF")
    
    # Try PyMuPDF (fitz) as fallback
    try:
        import fitz  # PyMuPDF
        
        doc = fitz.open(file_path)
        for page_num in range(len(doc)):
            page = doc[page_num]
            # Render page to image
            mat = fitz.Matrix(dpi / 72, dpi / 72)  # Scale matrix for DPI
            pix = page.get_pixmap(matrix=mat)
            img_data = pix.tobytes("png")
            base64_image = base64.b64encode(img_data).decode('utf-8')
            images.append((page_num + 1, base64_image))
        
        logger.info(f"[PDF] Converted {len(images)} pages to images using PyMuPDF")
        return images
    except ImportError:
        logger.warning("[PDF] PyMuPDF not available")
    except Exception as e:
        logger.error(f"[PDF] PyMuPDF failed: {e}")
    
    # If no image conversion available
    raise ImportError(
        "No PDF image conversion library available. "
        "Install pdf2image (with poppler) or PyMuPDF:\n"
        "  pip install pdf2image  # requires poppler-utils\n"
        "  pip install PyMuPDF"
    )


SYSTEM_PROMPT_VISION = """You are an expert chemist specializing in analyzing scientific literature and extracting chemical reaction data from images. 

Analyze the provided image(s) from a scientific paper and extract ALL chemical information you can see, including:

1. **Reaction Schemes**: Chemical structures, reaction arrows, reagents, conditions shown on arrows
2. **Tables**: Any data tables with yields, conditions, compound information
3. **Figures**: Graphs showing yield vs conditions, selectivity data, etc.
4. **Chemical Structures**: Named compounds, SMILES-like notations, molecular formulas
5. **Text in Images**: Any visible text including compound names, conditions, notes

Return a JSON object with this structure:
{
  "reactants": ["list of reactant names/structures you can identify"],
  "products": ["list of product names/structures you can identify"],
  "catalysts": ["list of catalysts"],
  "ligands": ["list of ligands"],
  "solvents": ["list of solvents mentioned"],
  "conditions": {
    "temperature": "temperature if shown",
    "time": "reaction time if shown",
    "pressure": "pressure if applicable",
    "atmosphere": "N2, Ar, air, etc."
  },
  "yields": [
    {"product": "product name", "yield": "yield value"}
  ],
  "selectivity": "selectivity information (ee, de, etc.)",
  "reactionType": "type of reaction shown",
  "mechanisms": ["any mechanistic information"],
  "image_description": "brief description of what is shown in the image",
  "additional_observations": "any other relevant chemical information seen"
}

Be thorough and extract ALL visible chemical information. If you see reaction schemes, describe the complete transformation. If you see tables, extract all relevant data."""


@data_extraction_bp.route('/api/extract/models', methods=['GET'])
def get_models():
    """Get available LLM models for extraction."""
    return jsonify({"success": True, "models": AVAILABLE_MODELS})


@data_extraction_bp.route('/api/extract', methods=['POST'])
def extract_data():
    """Extract chemical data from text using LLM."""
    from llm_providers import get_llm_response
    from utils import sanitize_input
    from errors import ValidationError
    
    try:
        data = request.get_json()
        if not data:
            raise ValidationError("No JSON data provided")
        
        text = data.get('text', '')
        provider = data.get('provider', 'deepseek')
        api_key = data.get('api_key')
        
        # Get the model, or use provider's default
        model = data.get('model')
        if not model:
            model = PROVIDER_DEFAULT_MODELS.get(provider, 'deepseek-chat')
        
        # Sanitize but allow longer text for PDFs
        max_length = 15000  # Increased for PDF content
        text = sanitize_input(text, max_length=max_length)
        if not text:
            raise ValidationError("Text cannot be empty", field="text")
        
        logger.info(f"[Data Extraction] Provider: {provider}, Model: {model}, Text length: {len(text)}")
        
        # Use existing LLM provider system
        user_message = f"Extract chemical reaction data from the following text:\n\n{text}"
        
        response = get_llm_response(
            SYSTEM_PROMPT,
            user_message,
            provider=provider,
            api_key=api_key,
            model=model,
            temperature=0.1,
            max_tokens=2000
        )
        
        if response:
            result = parse_extraction_result(response)
            
            # Check if result is empty (no data extracted)
            total_items = sum(len(result.get(k, [])) for k in ['reactants', 'products', 'catalysts', 'ligands', 'solvents', 'mechanisms'])
            if total_items == 0 and not result.get('conditions') and not result.get('yields'):
                logger.warning("[Data Extraction] No chemical data found in text")
                return jsonify({
                    "success": True,
                    "data": result,
                    "warning": "No chemical reaction data was found in the provided text. The text may not contain chemical reaction information, or you may need to try a different model or provider.",
                    "model_used": model,
                    "provider_used": provider
                })
            
            return jsonify({
                "success": True,
                "data": result,
                "model_used": model,
                "provider_used": provider
            })
        else:
            return jsonify({
                "success": False,
                "error": "No response from LLM. Please check your API key and provider settings."
            }), 500
    
    except ValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        logger.error(f"Data extraction error: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)}), 500


@data_extraction_bp.route('/api/extract/pdf', methods=['POST'])
def upload_pdf():
    """Upload and extract text from PDF."""
    from errors import ValidationError
    
    try:
        if 'file' not in request.files:
            raise ValidationError("No file provided")
        
        file = request.files['file']
        
        if file.filename == '':
            raise ValidationError("No file selected")
        
        filename = secure_filename(file.filename)
        if not filename.lower().endswith('.pdf'):
            raise ValidationError("Only PDF files are supported")
        
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        try:
            text, metadata = extract_pdf_text(tmp_path)
            
            # Check if text was extracted
            if not text or len(text.strip()) < 50:
                logger.warning(f"[PDF] Very little or no text extracted from PDF: {len(text.strip()) if text else 0} chars")
                return jsonify({
                    "success": False,
                    "error": "No extractable text found in PDF. The PDF may be image-based (scanned). Try using 'Extract from Images (Vision AI)' option instead.",
                    "text_length": len(text.strip()) if text else 0,
                    "metadata": metadata
                })
            
            logger.info(f"[PDF] Successfully extracted {len(text)} characters from {metadata.get('pages', 'unknown')} pages")
            
            return jsonify({
                "success": True,
                "text": text,
                "metadata": metadata,
                "text_length": len(text)
            })
        finally:
            # Clean up temp file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    except ValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except ImportError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    except Exception as e:
        logger.error(f"PDF extraction error: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)}), 500


@data_extraction_bp.route('/api/extract/pdf/vision', methods=['POST'])
def extract_pdf_with_vision():
    """Extract chemical data from PDF using vision-capable LLM.
    
    This endpoint converts PDF pages to images and uses a vision model
    to extract chemical reaction data from both text and images.
    
    Requires a vision-capable provider (OpenAI, Gemini, or Anthropic).
    """
    from errors import ValidationError
    
    try:
        if 'file' not in request.files:
            raise ValidationError("No file provided")
        
        file = request.files['file']
        
        if file.filename == '':
            raise ValidationError("No file selected")
        
        filename = secure_filename(file.filename)
        if not filename.lower().endswith('.pdf'):
            raise ValidationError("Only PDF files are supported")
        
        # Get provider and API key from form data
        provider = request.form.get('provider', 'openai')
        api_key = request.form.get('api_key')
        model = request.form.get('model')
        max_pages = int(request.form.get('max_pages', 5))  # Limit pages to avoid token limits
        
        # Check if provider supports vision
        if provider not in VISION_CAPABLE_MODELS:
            return jsonify({
                "success": False,
                "error": f"Provider '{provider}' does not support vision. Please use DeepSeek, OpenAI, Gemini, or Anthropic."
            }), 400
        
        # Use vision-capable model for the provider
        if not model:
            model = VISION_CAPABLE_MODELS[provider]
        
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        try:
            # First, extract text (as backup/additional context)
            text_content, pdf_metadata = extract_pdf_text(tmp_path)
            
            # Convert PDF to images
            page_images = pdf_to_images(tmp_path, dpi=150)
            
            # Limit pages
            if len(page_images) > max_pages:
                logger.info(f"[PDF Vision] Limiting to {max_pages} of {len(page_images)} pages")
                page_images = page_images[:max_pages]
            
            pdf_metadata['pages_analyzed'] = len(page_images)
            
            # Extract data from images using vision
            all_results = []
            
            for page_num, base64_image in page_images:
                logger.info(f"[PDF Vision] Analyzing page {page_num}")
                
                # Call vision LLM
                result = call_vision_llm(
                    base64_image,
                    provider=provider,
                    model=model,
                    api_key=api_key,
                    page_number=page_num
                )
                
                if result:
                    all_results.append({
                        "page": page_num,
                        "data": result
                    })
            
            # Merge results from all pages
            merged_result = merge_extraction_results(all_results)
            
            # Also include text content for reference
            merged_result['text_content'] = text_content[:5000] if text_content else ""
            
            return jsonify({
                "success": True,
                "data": merged_result,
                "metadata": pdf_metadata,
                "pages_analyzed": len(page_images),
                "model_used": model,
                "provider_used": provider
            })
            
        finally:
            # Clean up temp file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    except ValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except ImportError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    except Exception as e:
        logger.error(f"PDF vision extraction error: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)}), 500


def call_vision_llm(base64_image: str, provider: str, model: str, api_key: str, page_number: int) -> dict:
    """Call a vision-capable LLM to extract data from an image."""
    try:
        if provider == 'deepseek':
            return call_deepseek_vision(base64_image, model, api_key, page_number)
        elif provider == 'openai':
            return call_openai_vision(base64_image, model, api_key, page_number)
        elif provider == 'gemini':
            return call_gemini_vision(base64_image, model, api_key, page_number)
        elif provider == 'anthropic':
            return call_anthropic_vision(base64_image, model, api_key, page_number)
        else:
            logger.error(f"Unknown vision provider: {provider}")
            return None
    except Exception as e:
        logger.error(f"Vision LLM error for page {page_number}: {e}")
        return None


def call_deepseek_vision(base64_image: str, model: str, api_key: str, page_number: int) -> dict:
    """Call DeepSeek Vision API (OpenAI-compatible format)."""
    import requests
    
    # DeepSeek uses OpenAI-compatible API
    url = "https://api.deepseek.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": SYSTEM_PROMPT_VISION
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"Analyze this image (page {page_number} of a scientific paper) and extract all chemical reaction data:"
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{base64_image}"
                        }
                    }
                ]
            }
        ],
        "max_tokens": 2000,
        "temperature": 0.1
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        if response.status_code == 200:
            data = response.json()
            content = data['choices'][0]['message']['content']
            return parse_extraction_result(content)
        else:
            logger.error(f"DeepSeek Vision API Error: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        logger.error(f"DeepSeek Vision request error: {e}")
        return None


def call_openai_vision(base64_image: str, model: str, api_key: str, page_number: int) -> dict:
    """Call OpenAI GPT-4o Vision API."""
    import openai
    
    client = openai.OpenAI(api_key=api_key)
    
    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "system",
                "content": SYSTEM_PROMPT_VISION
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"Analyze this image (page {page_number} of a scientific paper) and extract all chemical reaction data:"
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/png;base64,{base64_image}",
                            "detail": "high"
                        }
                    }
                ]
            }
        ],
        max_tokens=2000,
        temperature=0.1
    )
    
    content = response.choices[0].message.content
    return parse_extraction_result(content)


def call_gemini_vision(base64_image: str, model: str, api_key: str, page_number: int) -> dict:
    """Call Google Gemini Vision API."""
    import google.generativeai as genai
    
    genai.configure(api_key=api_key)
    
    model_obj = genai.GenerativeModel(model)
    
    import PIL.Image
    import io
    
    image_data = base64.b64decode(base64_image)
    image = PIL.Image.open(io.BytesIO(image_data))
    
    response = model_obj.generate_content([
        SYSTEM_PROMPT_VISION,
        f"\n\nAnalyze this image (page {page_number} of a scientific paper) and extract all chemical reaction data:",
        image
    ])
    
    content = response.text
    return parse_extraction_result(content)


def call_anthropic_vision(base64_image: str, model: str, api_key: str, page_number: int) -> dict:
    """Call Anthropic Claude Vision API."""
    import anthropic
    
    client = anthropic.Anthropic(api_key=api_key)
    
    response = client.messages.create(
        model=model,
        max_tokens=2000,
        system=SYSTEM_PROMPT_VISION,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/png",
                            "data": base64_image
                        }
                    },
                    {
                        "type": "text",
                        "text": f"Analyze this image (page {page_number} of a scientific paper) and extract all chemical reaction data:"
                    }
                ]
            }
        ]
    )
    
    content = response.content[0].text
    return parse_extraction_result(content)


def merge_extraction_results(all_results: list) -> dict:
    """Merge extraction results from multiple pages."""
    merged = {
        "reactants": [],
        "products": [],
        "catalysts": [],
        "ligands": [],
        "solvents": [],
        "conditions": {},
        "yields": [],
        "mechanisms": [],
        "reactionType": None,
        "selectivity": None,
        "image_descriptions": [],
        "pages_with_data": []
    }
    
    for page_result in all_results:
        page_num = page_result["page"]
        data = page_result["data"]
        
        if not data:
            continue
        
        # Track which pages had data
        merged["pages_with_data"].append(page_num)
        
        # Merge lists (avoid duplicates)
        for key in ["reactants", "products", "catalysts", "ligands", "solvents", "mechanisms"]:
            if key in data and data[key]:
                for item in data[key]:
                    if item and item not in merged[key]:
                        merged[key].append(item)
        
        # Merge yields
        if "yields" in data and data["yields"]:
            for y in data["yields"]:
                if y not in merged["yields"]:
                    merged["yields"].append(y)
        
        # Merge conditions (prefer non-empty values)
        if "conditions" in data and data["conditions"]:
            for cond_key, cond_val in data["conditions"].items():
                if cond_val and not merged["conditions"].get(cond_key):
                    merged["conditions"][cond_key] = cond_val
        
        # Take first non-null values for these
        if not merged["reactionType"] and data.get("reactionType"):
            merged["reactionType"] = data["reactionType"]
        if not merged["selectivity"] and data.get("selectivity"):
            merged["selectivity"] = data["selectivity"]
        
        # Collect image descriptions
        if data.get("image_description"):
            merged["image_descriptions"].append({
                "page": page_num,
                "description": data["image_description"]
            })
    
    return merged


@data_extraction_bp.route('/api/extract/pdf/chemextract', methods=['POST'])
def extract_pdf_chemextract():
    """Extract chemical data from PDF using ChemExtract AI.
    
    This endpoint provides comprehensive extraction:
    1. Converts PDF pages to images
    2. Extracts figures, tables, and reaction schemes
    3. Uses LLM Vision to extract chemical data from images
    4. Extracts and processes text for reaction information
    5. Combines all results into a unified output
    
    ChemExtract AI uses multimodal extraction with LLM Vision
    for intelligent chemistry-focused data extraction.
    """
    from errors import ValidationError
    
    try:
        if 'file' not in request.files:
            raise ValidationError("No file provided")
        
        file = request.files['file']
        
        if file.filename == '':
            raise ValidationError("No file selected")
        
        filename = secure_filename(file.filename)
        if not filename.lower().endswith('.pdf'):
            raise ValidationError("Only PDF files are supported")
        
        # Get parameters from form data
        provider = request.form.get('provider', 'deepseek')
        api_key = request.form.get('api_key')
        model = request.form.get('model')
        max_pages = int(request.form.get('max_pages', 10))
        extract_figures = request.form.get('extract_figures', 'true').lower() == 'true'
        extract_text = request.form.get('extract_text', 'true').lower() == 'true'
        # Check if provider supports vision for figure extraction
        if extract_figures and provider not in VISION_CAPABLE_MODELS:
            return jsonify({
                "success": False,
                "error": f"Provider '{provider}' does not support vision. Figure extraction requires DeepSeek, OpenAI, Gemini, or Anthropic."
            }), 400
        
        # Use vision-capable model for the provider
        if not model:
            model = VISION_CAPABLE_MODELS.get(provider, PROVIDER_DEFAULT_MODELS.get(provider))
        
        # Save to temp file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        try:
            # Import ChemExtract AI extractor
            from chemextract_extractor import extract_chemical_data_from_pdf
            
            logger.info(f"[ChemExtract AI] Starting extraction for {filename}, provider={provider}, max_pages={max_pages}")
            
            # Perform extraction
            result = extract_chemical_data_from_pdf(
                tmp_path,
                llm_provider=provider,
                api_key=api_key,
                model=model,
                max_pages=max_pages
            )
            
            # Process results into unified format
            merged_data = {
                "reactants": [],
                "products": [],
                "catalysts": [],
                "ligands": [],
                "solvents": [],
                "conditions": {},
                "yields": [],
                "mechanisms": [],
                "reactionType": None,
                "selectivity": None,
                "smiles": {"reactants": [], "products": []}
            }
            
            # Merge all reactions found
            for reaction in result.get('reactions', []):
                # Merge reactants
                reactants = reaction.get('reactants', [])
                if isinstance(reactants, list):
                    for r in reactants:
                        if isinstance(r, dict):
                            name = r.get('name') or r.get('smiles', '')
                            if name and name not in merged_data['reactants']:
                                merged_data['reactants'].append(name)
                            if r.get('smiles') and r['smiles'] not in merged_data['smiles']['reactants']:
                                merged_data['smiles']['reactants'].append(r['smiles'])
                        elif isinstance(r, str) and r not in merged_data['reactants']:
                            merged_data['reactants'].append(r)
                
                # Merge products
                products = reaction.get('products', [])
                if isinstance(products, list):
                    for p in products:
                        if isinstance(p, dict):
                            name = p.get('name') or p.get('smiles', '')
                            if name and name not in merged_data['products']:
                                merged_data['products'].append(name)
                            if p.get('smiles') and p['smiles'] not in merged_data['smiles']['products']:
                                merged_data['smiles']['products'].append(p['smiles'])
                        elif isinstance(p, str) and p not in merged_data['products']:
                            merged_data['products'].append(p)
                
                # Merge catalysts
                catalysts = reaction.get('catalysts', [])
                if isinstance(catalysts, list):
                    for c in catalysts:
                        if isinstance(c, dict):
                            c_name = c.get('name', '')
                            if c_name and c_name not in merged_data['catalysts']:
                                merged_data['catalysts'].append(c_name)
                        elif isinstance(c, str) and c not in merged_data['catalysts']:
                            merged_data['catalysts'].append(c)
                
                # Merge ligands
                ligands = reaction.get('ligands', [])
                if isinstance(ligands, list):
                    for l in ligands:
                        if isinstance(l, dict):
                            l_name = l.get('name', '')
                            if l_name and l_name not in merged_data['ligands']:
                                merged_data['ligands'].append(l_name)
                        elif isinstance(l, str) and l not in merged_data['ligands']:
                            merged_data['ligands'].append(l)
                
                # Merge solvents
                solvents = reaction.get('solvents', [])
                if isinstance(solvents, list):
                    for s in solvents:
                        if isinstance(s, str) and s not in merged_data['solvents']:
                            merged_data['solvents'].append(s)
                
                # Merge conditions
                conditions = reaction.get('conditions', {})
                if isinstance(conditions, dict):
                    for key, val in conditions.items():
                        if val and not merged_data['conditions'].get(key):
                            merged_data['conditions'][key] = val
                
                # Merge yields
                yields = reaction.get('yields', [])
                if isinstance(yields, list):
                    for y in yields:
                        if y and y not in merged_data['yields']:
                            merged_data['yields'].append(y)
            
            return jsonify({
                "success": True,
                "data": merged_data,
                "metadata": {
                    "pages_processed": result.get('pages_processed', 0),
                    "figures_found": len(result.get('figures', [])),
                    "reactions_found": len(result.get('reactions', [])),
                    "extraction_method": result.get('metadata', {}).get('extraction_method', 'llm'),
                    "text_length": len(result.get('text_content', ''))
                },
                "raw_reactions": result.get('reactions', []),
                "model_used": model,
                "provider_used": provider
            })
            
        finally:
            # Clean up temp file
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    except ValidationError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except ImportError as e:
        return jsonify({
            "success": False, 
            "error": f"Missing dependency: {str(e)}. Please install required packages."
        }), 500
    except Exception as e:
        logger.error(f"ChemExtract AI extraction error: {e}", exc_info=True)
        return jsonify({"success": False, "error": str(e)}), 500
